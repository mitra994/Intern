package com.web.MarketStoreWebApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarketStore {

	public static void main(String[] args) {
		SpringApplication.run(MarketStore.class, args);
	}

}
