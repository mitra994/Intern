package com.web.MarketStoreWebApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarketStoreWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
